import { Component, OnInit } from '@angular/core';
import { PetService } from '../pet.service';
import { Router } from '@angular/router';
import { Pet } from '../pet';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-buy-pet',
  templateUrl: './buy-pet.component.html',
  styleUrls: ['./buy-pet.component.css']
})
export class BuyPetComponent implements OnInit {

  pet:Pet=new Pet();


  constructor(private petService: PetService, private router:Router) { }

  p: Number =1;
  count: Number= 3
  uid:number;

  ngOnInit(): void {
    this.buyPet();
  }

  buyPet(){
    let id=localStorage.getItem("id");
    this.petService.getPet(+id)  //convert string to number
    .subscribe(data=>{
      this.pet=data;
    })
  }
  
  onBuy(){
    console.log("into update");
    let userid=sessionStorage.getItem('uid');
    this.uid=+userid;
    this.petService.BuyPet(this.pet,this.uid)
    .subscribe(data => {
      console.log(data);
      this.router.navigate(["pet"]);
    }, error => console.log(error));
    this.pet =new Pet();
    }

 

 

}
