import { Injectable } from '@angular/core';
import { PetService } from './pet.service';
import { Pet } from './pet';
import { LoginComponent } from './login/login.component';
import { User } from './user';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  username: string;
  pass:string;
  uname:string;  

  user: User = new User();

  constructor(private petService: PetService) { }

  authenticate(name, password):Observable<any>{
    //database logic
    this.username=name;
    this.pass=password;
    return this.petService.CreateLogin(name) ;
  }
  isUserLoggedIn(){
    let user = sessionStorage.getItem('username')
    this.uname=user;
    return !(user === null)
  }
    
  logOut(){
    sessionStorage.removeItem('username')
  }
}
