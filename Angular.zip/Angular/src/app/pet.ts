export class Pet {
    id:number;
    type:string;
    dob:Date;
    price:number;
    gender:string;
}