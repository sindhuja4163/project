import { Component, OnInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { User } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class LoginComponent implements OnInit {

  user: User =new User();
  invalidLogin : boolean;
  username:string;
  password:string;

  error1:any="";

  constructor(private router: Router,
    private loginservice: AuthenticationService,
    private cd: ChangeDetectorRef) { }

  ngOnInit(): void {
  }

  checkLogin(){
    this.loginservice.authenticate(this.username, this.password)
    .subscribe(data => {
      this.user = data;
      this.cd.markForCheck();
      console.log(this.user);
      sessionStorage.setItem('uid',data.id);
      if(this.user.name == this.username && this.user.password == this.password){
        sessionStorage.setItem('username',this.username);
        this.router.navigate(["pet"]);
      }else{
        this.error1 = "Invalid Username or Password";
        this.router.navigate(["login"]);
      }
       },
       error=>{
         this.error1 = "Invalid Username or Password";
         console.log(error);
       });
      }


      refresh(){
        this.cd.detectChanges();
      }
      
}
