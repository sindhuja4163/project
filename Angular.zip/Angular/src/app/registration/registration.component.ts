import { Component, OnInit } from '@angular/core';
import { Pet } from '../pet';
import { PetService } from '../pet.service';
import { User } from '../user';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  submitted = false;
  user: User = new User();
  
  constructor(private petService: PetService) { }

  ngOnInit(): void {
  }

  save(){
    this.petService.createUser(this.user)
     .subscribe(
       data => {
         console.log(data);
         this.submitted=true;
       },
       error => console.log(error));
  this.user =new User();
  }
  


onSubmit(){
  this.save();
}

  
 
}
