import { Component, OnInit } from '@angular/core';
import { PetService } from '../pet.service';
import { Observable } from 'rxjs';
import { Pet } from '../pet';

@Component({
  selector: 'app-mypet',
  templateUrl: './mypet.component.html',
  styleUrls: ['./mypet.component.css']
})
export class MypetComponent implements OnInit {

  pets: Observable<Pet[]>;

  p: Number = 1;
  count: Number = 3;
  uid:number;

  constructor(private petService: PetService) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(){
    let userid=sessionStorage.getItem('uid');
    this.uid=+userid;
    this.pets =this.petService.getPetList(this.uid);
    
  }

}
