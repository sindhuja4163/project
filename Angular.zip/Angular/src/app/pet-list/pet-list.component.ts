import { Component, OnInit } from '@angular/core';
import { Pet } from '../pet';
import { Observable } from 'rxjs';
import { PetService } from '../pet.service';
import { Router } from '@angular/router';
import { StylesCompileDependency } from '@angular/compiler';

@Component({
  selector: 'app-pet-list',
  templateUrl: './pet-list.component.html',
  styleUrls: ['./pet-list.component.css']
})
export class PetListComponent implements OnInit {

  pets: Observable<Pet[]>;

  constructor(private petService: PetService, private router:Router) { }


  p: Number = 1;
  count: Number = 3;

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.pets =this.petService.getPetsList();
  }

  buyPet(pet: Pet):void{
    console.log("into buy");
    localStorage.setItem("id",pet.id.toString());
    this.router.navigate(["buy"]);
    
    
  }
  sold(){
    this.router.navigate(["pet"]);
  }
  
  

}
