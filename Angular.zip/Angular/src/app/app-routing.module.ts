import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreatePetComponent } from './create-pet/create-pet.component';
import { PetListComponent } from './pet-list/pet-list.component';
import { BuyPetComponent } from './buy-pet/buy-pet.component';
import { MypetComponent } from './mypet/mypet.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { AuthguardService } from './authguard.service';
import { LogoutComponent } from './logout/logout.component';

const routes: Routes = [
  {path: 'add', component: CreatePetComponent},
  {path: 'pet', component: PetListComponent,canActivate:[AuthguardService]},
  {path: 'mypets',component:MypetComponent},
  {path: 'buy',component:BuyPetComponent},
  {path: 'registration',component:RegistrationComponent},
  {path: 'login', component:LoginComponent},
  {path: '', redirectTo: 'pet',pathMatch: 'full'},
  {path: 'logout', component: LogoutComponent,canActivate:[AuthguardService]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
