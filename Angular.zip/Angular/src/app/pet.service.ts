import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PetService {

  private baseUrl = 'http://localhost:8080/api/pets';
  
  constructor(private http: HttpClient) { }

  createPet(pet: any): Observable<any> {
    return this.http.post(this.baseUrl, pet);
  }

  getPetsList(): Observable<any> {
    return this.http.get(this.baseUrl);
  }

  getPet(id: number): Observable<any>{
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  BuyPet(pet: Object,uid:number): Observable<Object>{
    return this.http.post(`${this.baseUrl}` + `/buy`+`/${uid}`,pet);
  }

  getPetList(uid:number): Observable<any> {
    return this.http.get(`${this.baseUrl}`+`/pet`+`/${uid}`);
  }

  createUser(pet: any): Observable<any> {
    return this.http.post(`${this.baseUrl}`+`/user`, pet);
  }

  CreateLogin(name: string): Observable<any>{
    return this.http.get(`${this.baseUrl}/name/${name}`);
  }

  
  
}
