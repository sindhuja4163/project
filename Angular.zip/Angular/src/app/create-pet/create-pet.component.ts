import { Component, OnInit } from '@angular/core';
import { Pet } from '../pet';
import { PetService } from '../pet.service';

@Component({
  selector: 'app-create-pet',
  templateUrl: './create-pet.component.html',
  styleUrls: ['./create-pet.component.css']
})
export class CreatePetComponent implements OnInit {

  submitted = false;
  pet: Pet = new Pet();

  constructor(private petService: PetService) { }

  ngOnInit(): void {
  }

  newPet():void{
    this.pet = new Pet();
    this.submitted = false;
  }

  save(){
      this.petService.createPet(this.pet)
       .subscribe(
         data => {
           console.log(data);
           this.submitted=true;
         },
         error => console.log(error));
    this.pet =new Pet();
    }
    
  

  onSubmit(){
    this.save();
  }
  

}
