package com.pack.SpringBootPet.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "mypet")
public class MyPet {

	@Id
	private long id;
	private long cid;
	private String type;
	private String dob;
	private Double price;
	
	@Column(name = "gender")
	@Enumerated(EnumType.STRING)
	private Gender gender;

	public MyPet() {
		super();
	
	}

	public MyPet(long id, String type, String dob, Double price, Gender gender) {
		super();
		this.id = id;
		this.type = type;
		this.dob = dob;
		this.price = price;
		this.gender = gender;
	}

	public MyPet(String type, String dob, Double price, Gender gender) {
		super();
		this.type = type;
		this.dob = dob;
		this.price = price;
		this.gender = gender;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public long getCid() {
		return cid;
	}

	public void setCid(long cid) {
		this.cid = cid;
	}

	
	
	
	
}
