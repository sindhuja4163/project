package com.pack.SpringBootPet.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.pack.SpringBootPet.model.MyPet;


public interface MyPetRepository extends CrudRepository<MyPet,Long>{

	List<MyPet> findByCid(long cid);
	

}
