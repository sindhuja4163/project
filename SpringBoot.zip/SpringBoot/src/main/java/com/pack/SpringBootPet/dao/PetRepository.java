package com.pack.SpringBootPet.dao;



import org.springframework.data.repository.CrudRepository;


import com.pack.SpringBootPet.model.Pet;



public interface PetRepository extends CrudRepository<Pet,Long>{

	
	

	



}

