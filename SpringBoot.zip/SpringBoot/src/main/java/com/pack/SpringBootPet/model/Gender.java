package com.pack.SpringBootPet.model;

public enum Gender {
	MALE,FEMALE

}
