package com.pack.SpringBootPet.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.SpringBootPet.dao.MyPetRepository;
import com.pack.SpringBootPet.dao.PetRepository;
import com.pack.SpringBootPet.dao.UserRepository;
import com.pack.SpringBootPet.model.MyPet;
import com.pack.SpringBootPet.model.Pet;
import com.pack.SpringBootPet.model.User;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class PetController {
	
	@Autowired
	PetRepository repository;
	@Autowired
	MyPetRepository repository1;
	@Autowired
	UserRepository repository2;
	
	private Logger log = Logger.getLogger(PetController.class);
	
	@PostMapping(value = "/pets")
	  public ResponseEntity<Pet> postPet(@RequestBody Pet pet) {
		log.info("saving pet to the database");
	    try {
	    	Pet p1 = new Pet(pet.getType(),pet.getDob(),pet.getPrice(),pet.getGender());
	    	p1.setStatus("Available");
	      Pet _pet = repository.save(p1);
	      return new ResponseEntity<>(_pet, HttpStatus.CREATED);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
	    }
	  }
	
	@GetMapping("/pets")
	public ResponseEntity<List<Pet>> getAllPets(){
		log.info("getting list of pets from database");
		List<Pet> pets = new ArrayList<Pet>();
		try {
			repository.findAll().forEach(pets::add);
			
			if(pets.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(pets,HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/pets/{id}")
	public ResponseEntity<Pet>getPetById(@PathVariable("id") long id){
		log.info("getting pet based on id");
		Optional<Pet> petData = repository.findById(id);
		
		if(petData.isPresent()) {
			Pet pet = petData.get();
			return new ResponseEntity<>(petData.get(), HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping(value= "/pets/buy/{cid}")
    public Pet BuyPet(@RequestBody Pet pet, @PathVariable long cid) {
		log.info("saving the buying pets into the database");
        pet.setStatus("SoldOut");
        repository.save(pet);
        MyPet pet1 = repository1.save(new MyPet(pet.getId(),pet.getType(),pet.getDob(),pet.getPrice(),pet.getGender())); 
        pet1.setCid(cid);
        repository1.save(pet1);
        return pet;
    }
	
	@GetMapping("/pets/pet/{cid}")
	public ResponseEntity<List<MyPet>> getAllMyPets(@PathVariable long cid){
		log.info("getting the list of soldout pets");
		List<MyPet> pets1 = new ArrayList<MyPet>();
		try {
			repository1.findByCid(cid).forEach(pets1::add );
			
			if(pets1.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(pets1,HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@PostMapping(value = "/pets/user")
	  public ResponseEntity<User> postUser(@RequestBody User user) {
		log.info("saving the user into the database");
	    try {
	    	User p1 = new User(user.getName(),user.getPassword(),user.getEmail(),user.getGender());
	    	User _user = repository2.save(p1);
	      return new ResponseEntity<>(_user, HttpStatus.CREATED);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
	    }
	  }
	
	@GetMapping(value = "pets/name/{name}")
	  public ResponseEntity<User> findByUserName(@PathVariable String name) {
		log.info("getting the user from database by username");
	    try {
	    	User prod= repository2.findByName(name);
	    	log.info(prod);
	    	 return new ResponseEntity<>(prod, HttpStatus.CREATED);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
	  }
	}
}
