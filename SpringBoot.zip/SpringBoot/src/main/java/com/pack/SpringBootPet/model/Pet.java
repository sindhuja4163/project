package com.pack.SpringBootPet.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name= "pets")
public class Pet {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String type;
	private String dob;
	private Double price;
	
	@Column(name = "gender")
	@Enumerated(EnumType.STRING)
	private Gender gender;
	private String status;
	public Pet() {
		super();
		
	}
	public Pet(long id, String type, String dob, Double price, Gender gender, String status) {
		super();
		this.id = id;
		this.type = type;
		this.dob = dob;
		this.price = price;
		this.gender = gender;
		this.status = status;
	}
	public Pet(String type, String dob, Double price, Gender gender, String status) {
		super();
		this.type = type;
		this.dob = dob;
		this.price = price;
		this.gender = gender;
		this.status = status;
	}
	public Pet(String type, String dob, Double price, Gender gender) {
		super();
		this.type = type;
		this.dob = dob;
		this.price = price;
		this.gender = gender;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	

	

	
	

}
